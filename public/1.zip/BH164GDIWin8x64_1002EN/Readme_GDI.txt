******************************************************************

Printer Driver for Windows XP, Server 2003, Vista, Server 2008, Server 2008 R2, 7 and 8

******************************************************************
******************************************************************

This README file includes the following information.

1. System Requirements
2. Installing using Plug and Play
    2.1 Installing the driver in Windows Vista/Server 2008
    2.2 Installing the driver in Windows XP/Server 2003
3. Installing using installer
    3.1 Installing the driver in Windows 7/8/Server 2008 R2
4. Uninstalling the driver
    4.1 Uninstalling the printer driver
    4.2 Uninstalling the scanner driver
5. Release Note
    5.1 General
    5.2 Problems with the Compatibility of Application Software

******************************************************************
Any processor of the same or higher specifications as recommended for your operating system.

1. System Requirements
    The following are operating environmental requirements for using the printer/scanner driver.
    * CPU
        Any processor of the same or higher specifications as recommended for your operating system.
    * Operating system
       32bit 
           Windows XP (Service Pack 3 or later)
           Windows Server 2003 (Service Pack 2 or later)
           Windows Vista (Service Pack 2 or later)
           Windows Server 2008 (Service Pack 2 or later)
           Windows 7
           Windows 8
       64bit
           Windows XP (Service Pack 2 or later)
           Windows Server 2003 (Service Pack 2 or later)
           Windows Vista (Service Pack 2 or later)
           Windows Server 2008 (Service Pack 2 or later)
           Windows Server 2008 R2
           Windows 7
           Windows 8
    * Memory
          Memory capacity as recommended for your operating system.
          Sufficient memory resource is required for your operating system and the applications to be used.
    * Interface
          USB2.0 (HI SPEED)
    * Driver
          CD-ROM drive



2. Installing using Plug and Play
    The printer/scanner driver can be installed using Plug and Play.
    Installing the driver requires the administrator authority.
    If the driver is installed using Plug and Play, first the scanner driver is installed, then installation
    of the printer driver begins. The procedure described in this Readme is for the installation 
    of the scanner driver, then the printer driver.
    Reference
         - Using Plug and Play is an easy way to install the driver. 
           Still, an additional printer wizard can also be used to install the printer driver. 
           To use the additional printer wizard, select the USB port to be connected 
           using [Choose a Printer Port].
         - In Windows 7/8/Server 2008 R2, use the installer to install the driver.

2.1 Installing the driver in Windows Vista/Server 2008
    (1) Connect this machine to the computer using a USB cable, then start the computer.
        NOTICE
        When starting up the computer, do not plug in or unplug the cable.
    (2) Turn on the power of this machine.
        The [Found New Hardware] dialog box appears.
        * If [Found New Hardware] dialog box does not appear, turn this machine off, then on again. In this
        case, turn off this machine, then wait approximately 10 seconds before turning it on again. If you
        turn this machine on immediately after turning it off, it may not function correctly.
    (3) Click [Locate and install driver software (recommended)].
        The dialog box requesting the disk (CD-ROM) appears.
        * If the [User Account Control] dialog box appears, click [Allow] or [Continue].
    (4) Click [I don't have the disc, show me other options].
    (5) Insert the driver CD-ROM into the CD-ROM drive of the computer.
    (6) Select [Browse my computer for driver software (advanced)], then specify a desired driver folder.
        * Select a folder according to the driver, operating system, and language to be used.
        e.g.: \GDI_diver\Win32\English
    (7) Click [Next].
        * If the [Windows Security] dialog box appears, click [Install this driver software anyway].
    (8) When the installation completes, click [Close].
        This completes the scanner driver installation. The [Found New Hardware] dialog box appears again,
        and the installation of the printer driver begins.
    (9) Repeat step (3) through step (8) to install the printer driver.
    (10)After finishing the installation, make sure that the icon for the installed printer is displayed in the [Printers]
        window.
    (11)Remove the CD-ROM from the CD-ROM drive.
        This completes the installation of the scanner driver and printer driver.

2.2 Installing the driver in Windows XP/Server 2003
    (1) Connect this machine to the computer using a USB cable, then start the computer.
        NOTICE
        When starting up the computer, do not plug in or unplug the cable.
    (2) Insert the driver CD-ROM into the CD-ROM drive of the computer.
    (3) Turn on the power of this machine.
        The [Found New Hardware Wizard] dialog box appears.
        * If the [Found New Hardware Wizard] dialog box does not appear, turn this machine off, then on
        again. In this case, turn off this machine, then wait approximately 10 seconds before turning it on
        again. If you turn this machine on immediately after turning it off, it may not function correctly.
        * If a dialog box with a message saying [Windows Update] appears, select [No].
    (4) Select [Install from a list or specific location (Advanced)], then click [Next >].
    (5) Under [Search for the best driver in these locations.], select [Include this location in the search:], then
        click [Browse].
    (6) Specify the desired driver folder and click [Open].
        * Select a folder according to the driver, operating system, and language to be used.
        e.g.: \GDI_diver\Win32\English
    (7) Click [Next >], then follow the instructions on the pages that follow.
        * If the [Windows Logo testing] or [Digital Signature] dialog box appears, click [Continue Anyway] or
        [Yes].
    (8) Click [Finish].
        This completes the scanner driver installation. The [Found New Hardware Wizard] dialog box appears
        again, and the installation of the printer driver begins.
    (9) Repeat step (4) through step (8) to install the printer driver.
    (10)After finishing the installation, make sure that the icon for the installed printer is displayed in the [Printers
        and Faxes] window.
    (11)Remove the CD-ROM from the CD-ROM drive.
        This completes the installation of the scanner driver and printer driver.



3. Installing using installer

3.1 Installing the driver in Windows 7/8/Server 2008 R2
    The printer/scanner driver can be installed using the installer.
    Installing the driver requires the administrator authority.
    > Do not connect the USB cable to the machine until the instruction appears.
    > Exit all running applications, if any.
    (1) Insert the driver CD-ROM into the CD-ROM drive of the computer.
        * Double-click [Setup.exe] for GDI printer driver or XPS printer driver on the CD-ROM, then go to Step (2).
        * If the [User Account Control] window appears, click [Allow], [Continue] or [Yes].
        * The scanner driver will not be installed together with the XPS printer driver.
    (2) From the pull-down menu, select the appropriate language, then click [OK].
    (3) Click [Next >].
    (4) To agree with all terms in the license agreement, select [I accept the terms of the License Agreement],
        then click [Next >].
    (5) From the pull-down menu, select the appropriate model, then click [Next >].
    (6) The installation of the driver begins.
        * If the [Windows Security] window appears for verifying the publisher, click [Install this driver software
        anyway].
    (7) When instructed to do so, connect the machine to your computer with a USB cable.
    (8) Click [Finish].



4. Uninstalling the driver
   The following explain the procedure to remove the driver.

4.1 Uninstalling the printer driver
    When you have to remove the printer driver, for example, when reinstallation of the printer driver is necessary,
    remove the driver using the following procedure.
    Uninstalling the driver requires the administrator authority.
    (1) Open the [Printers] window, [Printers and Faxes] window or [Devices and Printers] window.
    (2) Select the icon for the printer to be uninstalled.
    (3) Press the [Delete] key on the computer to uninstall the printer driver.
        * In Windows 7/8/Server 2008 R2, right-click on the icon, then click [Remove device].
    (4) From then on, follow the instructions on the pages that follow.
        When the printer driver has been deleted, the icon disappears from the [Printers] window, [Printers and
        Faxes] window or [Devices and Printers] window.
    (5) Open [Server Properties] or [Print Server Properties].
        * In Windows 7/8/Server 2008 R2, open the [Devices and Printers] window. Click an icon in the [Printers
        and Faxes] list and the [Print Server Properties] appears on the menu. Click the [Print Server Properties]
        from the menu.
        * In Windows Vista/Server 2008, right-click on the area that has nothing displayed in the [Printers]
        window, click [Run as administrator] - [Server Properties].
        * Windows XP/Server 2003, click the [File] menu, and then [Server Properties].
        * If the [User Account Control] window appears, click [Continue] or [Yes].
    (6) Click the [Driver] tab.
        * In Windows 7/8/Server 2008 R2, click [Change Driver Settings] located in the lower left corner of the
        window to run as the administrator authority.
    (7) From the [Installed printer drivers:] list, select the printer driver to be removed, then click [Remove...].
        * In Windows 7/8/Vista/Server 2008/Server 2008 R2, go to Step (8).
        * In Windows XP/Server 2003, go to Step (9).
    (8) In the dialog box for confirming the items to be removed, select [Remove driver and driver package.],
        then click [OK].
    (9) In the dialog box for confirming if you are sure to remove the printer, click [Yes].
        * In Windows 7/8/Vista/Server 2008/Server 2008 R2, the dialog box appears to reconfirm if you are
        sure. Click [Uninstall].
    (10)Close the open windows, then restart the computer.
        * Be sure to restart the computer.
        This completes removing the printer driver.
    Reference
    - In Windows XP/Server 2003, even if the printer driver is deleted using the preceding method, the model
      information file will remain in the computer. For this reason, when reinstalling the same version of the
      printer driver, the driver may not be rewritten. In this case, remove the following files as well.
    - Check the "C:\WINDOWS\system32\spool\drivers\w32e86" folder ("C:\WINDOWS\
      system32\spool\drivers\e64" folder in the e64 system, and if there is a folder of the corresponding
      model, remove it.
    - From the "C:\WINDOWS\inf" folder, remove "oem*.inf" and "oem*.PNF" ("*" included in the file name
      indicates a number, which differs depending on the computer environment). Before removing these
      files, open the inf file, then check the model name described on the last few lines to confirm it is the file
      for the corresponding model. The number of the PNF file is the same as that of the inf file.
    - In Windows 7/8/Vista/Server 2008/

4.2 Uninstalling the scanner driver
    When you have to remove the scanner driver, for example, when reinstallation of the scanner is necessary,
    remove the driver using the following procedure.
    Uninstalling the driver requires the administrator authority.
    (1) Click [Start], then select [All Programs] (or [Programs]) - [KONICA MINOLTA :*** Scanner] - [UnInstScan].
        ("***" indicates a model name.)
        * In Windows 7/8/Vista/Server 2008/Server 2008 R2, when the [User Account Control] window appears,
        click [Continue] or [Yes].
    (2) Click [Next >].
    (3) In the dialog box for confirming if you are sure to remove the scanner, click [Yes].
    (4) Click [Finish].
    (5) Close the open windows, and then restart the computer.
        * Be sure to restart the computer.
        This completes removing the scanner driver.



5. Release Note

5.1 General
    * Watermark of double-byte character may not be able to indicate by boldface.
    * If the Watermark is set by changing the zoom ratio from the driver,
    the zoom setting does not work for Watermark.

5.2 Problems with the Compatibility of Application Software
    Microsoft Word 2002/2003
    * In the transparent mode, some images may not be printed correctly.
    In this case, change the driver's contrast and perform printing.
    Corel DRAW
    * If a particular figure form is printed, it may not be printed correctly.



Microsoft and Windows are either registered trademarks or trademarks of Microsoft Corporation 
in the United States and/or other countries.
All other product and brand names are trademarks or registered trademarks of their respective companies or
organizations.